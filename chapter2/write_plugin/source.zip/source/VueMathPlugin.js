export default {
    install: function(Vue) {
        Vue.directive('square', function(el, bindind) {
            el.innerHTML = Math.pow(bindind.value, 2);  
        });
        Vue.directive('sqrt', function(el, bindind) {
            el.innerHTML = Math.sqrt(bindind.value);
        });
    }
};
